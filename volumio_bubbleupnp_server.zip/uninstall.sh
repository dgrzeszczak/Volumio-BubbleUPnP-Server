#!/bin/bash

# Uninstall dependendencies
# apt-get remove -y

sudo /opt/bin/ipkg remove  bubbleupnpserver-installer

echo "Done"
echo "pluginuninstallend"